import { createContext} from 'react'

const plantContext = createContext();

export default plantContext;